import java.util.ArrayList;
import java.util.Scanner;


public class Turma {
	public int TAM;
	public double mediaTurma;
	ArrayList<Aluno> Alunos = new ArrayList<Aluno>();
	
	
	
	public void receberAlunos() {
		System.out.println("Digite o tamanho da turma:");
		Scanner in1 = new Scanner(System.in);
		Scanner in2 = new Scanner(System.in);
		this.TAM = in1.nextInt();
		System.out.println("----------Alunos----------");
		for(int i = 0; i < TAM; i++) {
			Aluno aux = new Aluno();
			this.Alunos.add(aux);
			System.out.println("Nome:");
			Alunos.get(i).setNome(in2.nextLine());
			System.out.println("Notas:");
			for (int j = 0; j < 4; j++) {
				Alunos.get(i).setNota(j, in1.nextDouble());
			}
			Alunos.get(i).setMedia();

		}
		System.out.println("----------turma encerrada----------");
		in1.close();
		in2.close();
	}
	
	
	
	
	public void sortArray() {
		Aluno temp;
		for (int i = 1; i < TAM ; i++ ) {
			for (int j = i; j > 0 ; j-- ) {
	    	  	if(Alunos.get(j).getMedia() > Alunos.get(j - 1).getMedia()){
		        	temp = Alunos.get(j);
		        	Alunos.set(j, Alunos.get(j-1));
		        	Alunos.set(j - 1, temp);
	        	}
		    }
		}
	}
	
	public void printAlunos() {
		sortArray();
		System.out.println("----------Alunos----------");
		for (Aluno aluno : Alunos) {
			System.out.printf("Aluno: %s, Media: %.2f\n", aluno.getNome(), aluno.getMedia());
		}
	}
	
	
	public void printMediaTurma() {
		System.out.println("----------Media Turma----------");
		double totalMediaTurma = 0;
		for (Aluno aluno : Alunos) {
			totalMediaTurma += aluno.getMedia();
		}
		this.mediaTurma = totalMediaTurma / this.TAM;
		System.out.printf("%.2f\n", this.mediaTurma);
	}

	
	
}
