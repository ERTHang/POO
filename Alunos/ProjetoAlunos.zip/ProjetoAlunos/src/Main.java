
public class Main {
	public static void main(String[] args) {
		Turma udesc = new Turma();
		udesc.receberAlunos();
		udesc.printAlunos();
		udesc.printMediaTurma();
	}
}
